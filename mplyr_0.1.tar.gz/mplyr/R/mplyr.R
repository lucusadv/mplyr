#' mplyr: Library for matrix manipulation 
#'    
#' @import reshape2 ggplot2 gridExtra dplyr magrittr zoo
#' @docType package
#' @name mplyr
#' @author G.A.Paleologo 
NULL
