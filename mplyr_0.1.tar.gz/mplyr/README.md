# mplyr
A library for the manipulation of n-dimensional arrays, in the spirit of dplyr for data frames. The package is still in alpha, so please don't use.
